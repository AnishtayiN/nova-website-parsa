<?php
/**
 * نوآوا — متغیرهای محیطی پیکربندی
 * این فایل باید در `.gitignore` قرار گیرد.
 */

// اطلاعات ورود اولیه (فقط برای ساخت اکانت در اولین اجرا)
define('DEFAULT_ADMIN_USER', getenv('DEFAULT_ADMIN_USER') ?: 'admin');
define('DEFAULT_ADMIN_PASS', getenv('DEFAULT_ADMIN_PASS') ?: '');  // خالی بگذارید تا از کاربر خواسته شود

// مسیر لاگ خطاها
define('ERROR_LOG_PATH', __DIR__ . '/data/error.log');